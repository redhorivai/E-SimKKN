<html>
<head><title>Verified By RSUD Palembang BARI</title></head>
    <body>

    <center>
        <img src="<?= base_url(); ?>/image/info/verified.png" style="width:100%;height:100%;">
    </center>

    </body>
</html>