<!-- FOOTER -->
<footer class="br-footer">
    <div class="footer-left">
        <div class="mg-b-2">Copyright &copy;
            <script>
                document.write(new Date().getFullYear());
            </script>
            . All Rights Reserved.</div>
        <div>Redho Rivai SriberTech</div>
    </div>
    <div class="footer-right d-flex align-items-center"></div>
</footer>

</div><!-- End content -->
<!-- END FOOTER -->